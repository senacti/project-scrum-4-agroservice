# Sistema de Gestión de Inventarios

![a](https://github.com/carmonabernaldiego/inventory/assets/43613125/156d0afd-573f-4c8b-b5a4-c09955556e10)
